var express = require('express');
var urlencodedParser = require('urlencoded-parser');
const bodyParser = require('body-parser');
var alert = require('alert');
const e = require('express');
const app = express();
const res = require('express/lib/response');
const { urlencoded } = require('body-parser');

app.use(express.urlencoded({extended:false}));

app.use(express.static(__dirname + "Page.html"));
app.use(express.static(__dirname + "User.html"));
app.use(express.static(__dirname + "Input.html"));

app.get('/', function (req, res) 
{
    res.sendFile('Page.html', { root: __dirname })
});

app.get('/admin',urlencodedParser, function (req, res) {
    res.sendFile(__dirname + "/Input.html");
});



app.post('/Sub', function (req, res) 
{
    var name = req.body.username;
    var ssn = req.body.usn;

    console.log(name,ssn);
    if(name!="" || ssn!="")
    {
        res.redirect("/");
    }
    else
    {
        alert('All Fields are Mandatory');
    }

});

app.listen(8080, function (req, res) 
{
    console.log("Running..")
});